# J.A.R.V.I.S. — Free Mobile PWA v1

This is a local-first working build based on the supplied JARVIS HUD.

## Run on Android

1. Put the `app` folder into a GitHub repository.
2. Enable GitHub Pages for the repository's `main` branch and root folder.
3. Open the published HTTPS URL in Chrome on Android.
4. Use Chrome's **Add to Home screen / Install app** option.

## Current free/local capabilities

- Futuristic JARVIS HUD
- Local tasks
- Local memory
- Local goal tracking
- JEE / fitness / grooming / earning-skill command routing
- Browser speech recognition where supported
- Browser text-to-speech where supported
- PWA manifest
- Offline service worker
- Phone-safe command handling

## Important

The first version does not pretend to have unrestricted Android control, always-on background wake-word detection, or unlimited cloud AI. Those require native Android permissions and/or external services.

The AI/web layer can be connected later through a secure backend without exposing API keys in the browser.
