# J.A.R.V.I.S. — Personal AI Operating System

**ARISE. ASSIST. THINK. EXECUTE. EVOLVE.**

A mobile-first, local-first Progressive Web App prototype for a personal AI operating system.

## Current version

J.A.R.V.I.S. PWA v1

## Features

- Futuristic JARVIS HUD interface
- Local tasks and goals
- Local notes and memory
- Browser speech input where supported
- Browser text-to-speech
- Study/JEE assistance flows
- Fitness and healthy-routine guidance flows
- Grooming and skill-learning guidance flows
- Offline PWA caching
- Installable from Chrome on Android

## Run locally

Open `app/index.html` in a browser, or serve the `app` folder over HTTPS/localhost for full PWA and speech features.

## GitHub Pages

1. Create a GitHub repository named `JARVIS-Personal-AI-OS`.
2. Upload the contents of this repository.
3. In **Settings → Pages**, choose **Deploy from a branch**.
4. Select `main` and `/app` if your Pages configuration supports a folder source, or move the app files to the repository root for the simplest Pages setup.
5. Open the generated HTTPS URL in Chrome on Android.
6. Choose **Add to Home screen / Install app**.

## Important limitations

This v1 is a browser/PWA application. It does not bypass Android security, provide unrestricted device control, guarantee an always-on background wake word, or contain an unlimited cloud AI model by itself.

Those capabilities require appropriate Android APIs, permissions, and/or connected AI services.
