/* J.A.R.V.I.S. Personal OS — free local-first application layer */
(() => {
  'use strict';
  const KEY='JARVIS_OS_V1';
  const defaults={tasks:[{id:1,text:'Revise today\'s highest-priority topic',done:false,category:'JEE'}],notes:[],memory:[],goals:[{name:'JEE Main + Advanced',progress:0},{name:'Healthy fitness',progress:0},{name:'Useful earning skills',progress:0}],settings:{voice:true,proactive:true,user:'Sir'}};
  const load=()=>{try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return structuredClone(defaults)}};
  let db=load();
  const save=()=>localStorage.setItem(KEY,JSON.stringify(db));
  const speak=(text)=>{ if(!db.settings.voice||!('speechSynthesis' in window))return; speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(text); u.lang='en-IN'; u.rate=.95; u.pitch=.95; speechSynthesis.speak(u); };
  const log=(msg)=>{ const feed=document.querySelector('#feed'); if(feed){const d=document.createElement('div');d.className='hud-log__row';d.innerHTML='<i class="hud-dot is-live"></i><span class="hud-log__t">JARVIS</span><span class="hud-log__v">'+esc(msg)+'</span>';feed.prepend(d);} };
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const render=()=>{
    const today=document.querySelector('#today'); if(today) today.innerHTML=db.tasks.slice(0,8).map(t=>`<div class="hud-log__row"><i class="hud-dot ${t.done?'is-ok':'is-live'}"></i><span class="hud-log__t">${esc(t.category||'TASK')}</span><span class="hud-log__v">${t.done?'DONE':'OPEN'} · ${esc(t.text)}</span></div>`).join('')||'<div class="hud-log__row"><span class="hud-log__v">No tasks.</span></div>';
    const ring=document.querySelector('#ringv'); if(ring) ring.textContent=Math.round((db.goals.reduce((a,g)=>a+g.progress,0)/(db.goals.length||1)))+'%';
    const chips=document.querySelector('#chips'); if(chips) chips.innerHTML=db.goals.map(g=>`<span class="hud-chip">${esc(g.name)} ${g.progress}%</span>`).join('');
  };
  function response(q){
    const s=q.trim(), l=s.toLowerCase();
    if(!s)return 'I\'m listening, sir.';
    if(/\b(hello|hi|hey)\b/.test(l))return 'Hello, sir. I\'m ready.';
    if(/\b(time|what time)\b/.test(l))return 'It is '+new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})+', sir.';
    if(/\b(date|today)\b/.test(l))return 'Today is '+new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'})+', sir.';
    if(/\b(tasks?|to do|todo)\b/.test(l)) {const open=db.tasks.filter(x=>!x.done);return open.length?`You have ${open.length} open task${open.length>1?'s':''}, sir. The first is: ${open[0].text}.`:'All tasks are complete, sir.';}
    if(/\b(add|create|make)\b.*\b(task|todo)\b/.test(l)){const text=s.replace(/.*?\b(task|todo)\b\s*(to)?\s*/i,'').trim()||'New task';db.tasks.unshift({id:Date.now(),text,done:false,category:'GENERAL'});save();render();return `Done, sir. I added: ${text}.`;}
    if(/\b(remember|memorize)\b/.test(l)){const text=s.replace(/.*?\b(remember|memorize)\b\s*/i,'').trim();if(text){db.memory.unshift({id:Date.now(),text});save();return `I'll remember that locally, sir.`;}return 'What would you like me to remember, sir?';}
    if(/\b(memory|memories)\b/.test(l))return db.memory.length?`I have ${db.memory.length} saved local memor${db.memory.length===1?'y':'ies'}, sir.`:'Your local memory is empty, sir.';
    if(/\b(note|notes)\b/.test(l))return `You have ${db.notes.length} local note${db.notes.length===1?'':'s'}, sir.`;
    if(/\bjee\b|\bphysics\b|\bchemistry\b|\bmathematics\b/.test(l))return 'JEE mode is ready, sir. I can organize revision, track tasks and run a local study session. Cloud AI can be connected later for deeper reasoning.';
    if(/\b(fitness|workout|gym|physique)\b/.test(l))return 'Fitness mode is ready, sir. I can organize healthy training, recovery and nutrition habits without extreme routines.';
    if(/\b(grooming|skin|acne|dandruff|tanning|hair)\b/.test(l))return 'Grooming mode is ready, sir. I can organize simple, evidence-aware skincare, haircare and sun-protection routines.';
    if(/\b(earn|earning|money|freelanc|career|skill)\b/.test(l))return 'Skill mode is ready, sir. I can help you learn coding, AI, communication and other legitimate skills through projects and practice.';
    if(/\b(unlock|bypass).*(phone|mobile)|phone.*unlock/.test(l))return 'I cannot bypass your phone security, sir. Please authenticate normally.';
    if(/\b(stop|cancel|never mind)\b/.test(l)){speechSynthesis?.cancel();return 'Cancelled, sir.';}
    if(/\b(go to sleep|sleep|stand by)\b/.test(l))return 'Good night, sir. I\'ll be standing by.';
    return 'I understand the request, sir. This local build can handle its built-in tools now. For open-ended reasoning and current web information, connect an AI/search service through the secure backend when you are ready.';
  }
  function ask(q){log(q);const a=response(q);const c=document.querySelector('#convo');if(c)c.textContent=a;log(a);speak(a);render();}
  window.JARVIS={ask,db,save,render,speak};
  document.addEventListener('DOMContentLoaded',()=>{
    render();
    const talk=document.querySelector('#talk');
    const brief=document.querySelector('#brief');
    if(brief)brief.onclick=()=>ask('Give me my briefing');
    if(talk){talk.onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){ask('voice unavailable');return}const r=new SR();r.lang='en-IN';r.interimResults=false;r.maxAlternatives=1;talk.classList.add('listening');talk.textContent='◉ LISTENING';r.onresult=e=>ask(e.results[0][0].transcript);r.onerror=()=>{talk.classList.remove('listening');talk.innerHTML='🎙 TALK'};r.onend=()=>{talk.classList.remove('listening');talk.innerHTML='🎙 TALK'};try{r.start()}catch{}}}
    if('serviceWorker' in navigator) navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
    log('LOCAL CORE ONLINE');
    setTimeout(()=>speak('JARVIS online. Local systems ready, sir.'),700);
  });
})();
